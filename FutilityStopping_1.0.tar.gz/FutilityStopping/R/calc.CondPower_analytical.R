.calc.CondPower_analytical = function(
  p.er.pe, p.pe.1_cp, p.pe.0_cp,
  coh1.pe, coh2.er,
  n.1, n.0, n.interim.1, n.interim.0, 
  n.coh1.1, n.coh1.0, alternative, 
  alpha, ni.margin
){
  
  if ((alternative==c("greater") | alternative==c("less"))==FALSE) {stop ("The specification of the alternative=c(\"...\") argument of the call is incorrect. Use either alternative=c(\"greater\"), or alternative=c(\"less\").")}     

  ### Conditional Probabilities ###
  k.1 = p.er.pe[1]; k.0 = p.er.pe[2]  #k.1 = P(Y=1|X=1, A=1); k.0 = P(Y=1|X=1, A=0)
  q.1 = p.er.pe[3]; q.0 = p.er.pe[4]
  
  ### Pooled Variance ###
  r = n.1/n.0
  P = (r*p.pe.1_cp + p.pe.0_cp)/(r+1)
  sigma = sqrt(P*(1-P))
  
  ### Some values ###
  n.coh2.1 = n.interim.1 - n.coh1.1; n.coh2.0 = n.interim.0 - n.coh1.0
  n.coh3.1 = n.1 - n.interim.1; n.coh3.0 = n.0 - n.interim.0
  
  eventType = switch(alternative,
                     greater = 1,
                     less = -1)
  
  delta = eventType*(p.pe.1_cp - p.pe.0_cp)
  
  ### Observed P(ER) in treatment and placebo group ###
  prob.er.1 = coh2.er[1]/n.coh2.1
  prob.er.0 = coh2.er[2]/n.coh2.0
  
  ### Test Statistic in cohort 1 ###
  if(n.coh1.0 != 0 & n.coh1.0 != 0){
    vector.1 = c(coh1.pe[1], coh1.pe[2], n.coh1.1-coh1.pe[1], n.coh1.0-coh1.pe[2])
    
    zt.coh1 = switch(alternative, 
                     greater = .TestStatistic.positive(vector.1, ni.margin = ni.margin),
                     less = .TestStatistic.negative(vector.1, ni.margin= ni.margin))
   
    
  }
  else {
    zt.coh1 = 0
  }
  
  
  ### Support Values ### 
  # delta_p
  delta_p = eventType*(prob.er.1*k.1 + (1 - prob.er.1)*q.1 - prob.er.0*k.0 - (1 - prob.er.0)*q.0)
  
  # sigma_p
  sigma_p = ((prob.er.1*k.1*(1 - k.1) + (1 - prob.er.1)*q.1*(1 - q.1))/r + 
               prob.er.0*k.0*(1 - k.0) + (1 - prob.er.0)*q.0*(1-q.0))/(1/r+1)
  
  # Expectation E_c(Z_n)
  A = zt.coh1*sqrt(n.coh1.0/n.0) + ((delta_p-ni.margin)/(sigma*sqrt(1/r+1)))*(n.coh2.0/sqrt(n.0)) + ((delta-ni.margin)/(sigma*sqrt(1/r+1)))*(n.coh3.0/sqrt(n.0))
  
  # Variance Var_c(Z_n)
  B = (sigma_p/sigma^2)*(n.coh2.0/n.0) + n.coh3.0/n.0
  
  ### Conditional Power ###
  fit = 1 - pnorm((qnorm(1-alpha) - A)/sqrt(B))
  
  class(fit) = "calc.CondPower_analytical"
  fit
  
}
