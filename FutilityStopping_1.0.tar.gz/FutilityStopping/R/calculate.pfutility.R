.calculate.pfutility = function(gamma, x){
  
  fit = mean(x<gamma)
  class(fit) = "calculate.pfutility"
  fit
  
} 
