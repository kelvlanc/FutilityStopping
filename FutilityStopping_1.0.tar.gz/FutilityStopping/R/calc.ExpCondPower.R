.calc.ExpCondPower = function(n.1, n.0, n.interim.1, n.interim.0,
                              n.coh1.1, n.coh1.0, p.pe.1_cp, p.pe.0_cp,
                              table.1, table.0, 
                              X.posterior.1, X.posterior.0, coh1.pe, 
                              coh2.er, alternative, alpha, method, assumption,
                              n.simqk, ni.margin){
  

  # Simulate q and k in Treatment Group
  qk.trt = switch(assumption, 
                    design = .sim.qk(p.pe = p.pe.1_cp, table = table.1, 
                                     X.posterior = X.posterior.1, n.sim = n.simqk),
                    trend = .sim.qk_betabeta(table = table.1, n.sim = n.simqk))
  
  # Simulate q and k in Placebo Group
  qk.pbo = switch(assumption, 
                  design = .sim.qk(p.pe = p.pe.0_cp, table = table.0, 
                                   X.posterior = X.posterior.0, n.sim = n.simqk),
                  trend = .sim.qk_betabeta(table = table.0, n.sim = n.simqk))
  
  eta = cbind(qk.trt$k.sim, qk.pbo$k.sim, qk.trt$q.sim, qk.pbo$q.sim)
  
  
  cp_values = switch(method, 
              simulation = apply(eta, FUN = .calc.CondPower_simulation, MARGIN = 1, 
                                      p.pe.1_cp = p.pe.1_cp, p.pe.0_cp = p.pe.0_cp, 
                                      coh1.pe = coh1.pe, coh2.er = coh2.er, 
                                      n.1= n.1, n.0 = n.0, n.interim.1 = n.interim.1, 
                                      n.interim.0 = n.interim.0, n.coh1.1 = n.coh1.1, 
                                      n.coh1.0 = n.coh1.0, alternative = alternative, 
                                      alpha = alpha,
                                      ni.margin = ni.margin),
              analytical = apply(eta, FUN = .calc.CondPower_analytical, MARGIN = 1, 
                                      p.pe.1_cp = p.pe.1_cp, p.pe.0_cp = p.pe.0_cp,
                                      coh1.pe = coh1.pe, coh2.er = coh2.er, 
                                      n.1 = n.1, n.0 = n.0, n.interim.1 = n.interim.1, 
                                      n.interim.0 = n.interim.0, n.coh1.1 = n.coh1.1,
                                      n.coh1.0 = n.coh1.0, alternative = alternative, 
                                      alpha = alpha, ni.margin = ni.margin))
  
  cp = mean(cp_values)
  
  fit = list(ExpectedConditionalPower = cp, cp_values = cp_values, eta = eta)
  class(fit) = "calc.ExpCondPower"
  fit
  
  
}
