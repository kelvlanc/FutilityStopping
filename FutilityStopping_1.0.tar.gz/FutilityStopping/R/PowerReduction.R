.PowerReduction = function(cutoff, x, p.rej, alpha, n){
  
  fit = length(which(p.rej<alpha & x<cutoff))/n
  
  class(fit) = "PowerReduction"
  fit
}
