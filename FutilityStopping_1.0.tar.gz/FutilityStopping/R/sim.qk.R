.sim.qk=function(p.pe, table, X.posterior, n.sim){
  
  delta1 = rbeta(n.sim, table[1], table[3])
  delta0 = rbeta(n.sim, table[2], table[4])
  pi = p.pe

  k.simulated = (delta1*pi)/(delta1*pi+delta0*(1-pi))
  q.simulated = ((1-delta1)*pi)/((1-delta1)*pi+(1-delta0)*(1-pi))

  fit = list(k.sim=k.simulated, q.sim=q.simulated)
  class(fit) = "sim.qk"
  fit

}

.sim.qk_betabeta = function(table, n.sim){
  
  k.simulated= rbeta(n.sim, table[1], table[2])
  q.simulated=rbeta(n.sim, table[3], table[4])
  
  fit = list(k.sim=k.simulated, q.sim=q.simulated)
  class(fit) = "sim.qk"
  fit
  
}




