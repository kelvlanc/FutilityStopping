summary.Ecp = function(object, ..., Object){

  
  if(missing(Object)){Object = object}
  coh1.pe = c(Object$coh1.er.pe.1[1] + Object$coh1.er.pe.1[3], Object$coh1.er.pe.0[1] + Object$coh1.er.pe.0[3])
  coh1.er = c(Object$coh1.er.pe.1[1] + Object$coh1.er.pe.1[2], Object$coh1.er.pe.0[1] + Object$coh1.er.pe.0[2])
  n.coh1.1 = sum(Object$coh1.er.pe.1)
  n.coh1.0 = sum(Object$coh1.er.pe.0)
  n.interim.1 = n.coh1.1 + Object$coh2.er[1] + Object$coh2.er[3]
  n.interim.0 = n.coh1.0 + Object$coh2.er[2] + Object$coh2.er[4]
  
  coh1.rate_er.1 = coh1.er[1]/n.coh1.1
  coh1.rate_er.0 = coh1.er[2]/n.coh1.0
  coh1.rate_pe.1 = coh1.pe[1]/n.coh1.1
  coh1.rate_pe.0 = coh1.pe[2]/n.coh1.0
  coh2.rate_er.1 = Object$coh2.er[1]/(n.interim.1 - n.coh1.1)
  coh2.rate_er.0 = Object$coh2.er[2]/(n.interim.0 - n.coh1.0)
  
  cat("\nFunction call:\n\n")
  print(Object$Call)
  
  cat(paste("\n______________________________________________________________________________________________________\n"))
   
  cat(paste("\n \nTotal Number Randomized in Experimental Arm                   =",Object$n.1))
  cat(paste("\n \nTotal Number Randomized in Control Arm                        =",Object$n.0))
  
  cat(paste("\n______________________________________________________________________________________________________\n"))
  
  cat(paste("\n\n Cohort 1"))
  cat(paste("\n\nObserved Early-Response Rate"))
  cat(paste("\n            Experimental Arm   =",round(coh1.rate_er.1,3)," ",coh1.er[1],"/",n.coh1.1))
  cat(paste("\n            Control Arm        =",round(coh1.rate_er.0,3)," ",coh1.er[2],"/",n.coh1.0))
  
  
  cat(paste("\n\nObserved Primary-Response Rate "))
  cat(paste("\n            Experimental Arm   =",round(coh1.rate_pe.1,3)," ",coh1.pe[1],"/",n.coh1.1))
  cat(paste("\n            Control Arm        =",round(coh1.rate_pe.0,3)," ",coh1.pe[2],"/",n.coh1.0))
  
  
  cat(paste("\n\n\nCross-tabulation Early Response x Primary Endpoint - Experimental Arm\n \n"))
  cat(paste("                                      Primary Endpoint\n"))
  cat(paste("                              Early Responder      Early Non-Responders\n"))
  cat(paste("Early-Response Responder        ",Object$coh1.er.pe.1[1],"              ",Object$coh1.er.pe.1[2],"\n"))
  cat(paste("               Non-Responder    ",Object$coh1.er.pe.1[3],"              ",Object$coh1.er.pe.1[4],"\n"))
  
  cat(paste("\n\n\nCross-tabulation Early Response x Primary Endpoint - Control Arm\n \n"))
  cat(paste("                                      Primary Endpoint\n"))
  cat(paste("                              Early Responder      Early Non-Responders\n"))
  cat(paste("Early-Response Responder        ",Object$coh1.er.pe.0[1],"              ",Object$coh1.er.pe.0[2],"\n"))
  cat(paste("               Non-Responder    ",Object$coh1.er.pe.0[3],"              ",Object$coh1.er.pe.0[4],"\n"))
  
  cat(paste("\n______________________________________________________________________________________________________\n"))
  
  cat(paste("\n\n Cohort 2"))
  cat(paste("\n\nObserved Early-Response Rate"))
      cat(paste("\n            Experimental Arm   =",round(coh2.rate_er.1,3)," ",Object$coh2.er[1],"/",n.interim.1 - n.coh1.1))
      cat(paste("\n            Control Arm        =",round(coh2.rate_er.0,3)," ",Object$coh2.er[2],"/",n.interim.0 - n.coh1.0))
      
  
  cat(paste("\n______________________________________________________________________________________________________\n"))
  
  cat("\nExpected Bayesian Posterior Probability: ")
  print(as.numeric(Object$ExpectedConditionalPower))
  
}