summary.sim.Ecp = function(object, ..., Object){
  
  if(missing(Object)){Object = object}
  
  gammas = c("0.0:", "0.1:", "0.2:", "0.3:", "0.4:", "0.5:", "0.6:", "0.7:", "0.8:", "0.9:", "1.0:")
  table = as.data.frame(Object$fraction.gammas, row.names = gammas)
  
  cat("\nFunction call:\n\n")
  print(Object$Call)
  
  cat(paste("\n______________________________________________________________________________________________________\n"))
  
  cat("\nFraction of trials with CP under cutoff:", as.numeric(Object$fraction.cutoff))
  #print(as.numeric(Object$fraction.cutoff))
  
  cat(paste("\n______________________________________________________________________________________________________\n"))
  
  cat("\n\nFraction of trials with CP under\n ")
  print(table)

}

