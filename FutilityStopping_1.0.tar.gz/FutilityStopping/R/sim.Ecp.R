sim.Ecp = function(n.1, n.0, n.coh1.1, n.coh1.0, n.interim.1, n.interim.0, 
                            prior.1 = c(0, 0, 0, 0), prior.0 = c(0, 0, 0, 0),
                            p.pe.1_cp = NULL, p.pe.0_cp = NULL, 
                            p.er.1, p.er.0, p.pe.1, p.pe.0,
                            log.OR.1, log.OR.0, alternative = c("greater"), alpha = 0.025,
                            method = c("analytical"), assumption = c("design"), 
                            cutoff = 0.50, n.simqk = 2500, 
                            n.trials = 10000, ni.margin = 0){                            
  
  if ((alternative==c("greater") | alternative==c("less"))==FALSE) {stop ("The specification of the alternative=c(\"...\") argument of the call is incorrect. Use either alternative=c(\"greater\"), or alternative=c(\"less\").")}     
  if ((method==c("simulation") | method==c("analytical"))==FALSE) {stop ("The specification of the method=c(\"...\") argument of the call is incorrect. Use either method=c(\"simulation\"), or method=c(\"analytical\").")}     
  if ((assumption==c("design") | assumption==c("trend"))==FALSE) {stop ("The specification of the design=c(\"...\") argument of the call is incorrect. Use either assumption=c(\"design\"), or assumption=c(\"trend\").")}     
  
  if((missing(p.pe.1_cp) | missing(p.pe.0_cp)) && assumption==c("design")) {stop ("The specification of p.pe.1_cp of p.pe.0_cp is missing.")}
  
  
  ### Some values ###
  n.coh2.1 = n.interim.1 - n.coh1.1; n.coh2.0 = n.interim.0 - n.coh1.0

  qk.1 = .calculate.qk(p.pe.1, p.er.1, log.OR.1)
  qk.0 = .calculate.qk(p.pe.0, p.er.0, log.OR.0)
  
  p11.1 = qk.1$k.sim
  p11.0 = qk.0$k.sim
  p01.1 = qk.1$q.sim
  p01.0 = qk.0$q.sim
  
  ExpectedConditionalPower = list(NULL)
  p.rej_final = c()
  total = list(NULL)
  
  for(i in 1:n.trials){
    
    cat(paste(i," \n"))
    
    ###################################
    ###### Generate Interim Data ###### 
    ###################################
    
    
    ### Cohort 1: both endpoints are available ###
    # Early response endpoint
    coh1.er.1 = rbinom(n = 1, size = n.coh1.1, p.er.1)
    coh1.er.0 = rbinom(n = 1, size = n.coh1.0, p.er.0)
    coh1.er = cbind(coh1.er.1, coh1.er.0, n.coh1.1 - coh1.er.1, n.coh1.0 - coh1.er.0)
    
    # Primary endpoint
    coh1.pe_1 = rbinom(n = 4, size = coh1.er, c(p11.1, p11.0, p01.1, p01.0))
    coh1.pe = cbind(coh1.pe_1[1] + coh1.pe_1[3], coh1.pe_1[2] + coh1.pe_1[4])
    
    ### Cohort 2: only ER is available ###
    # Early response endpoint
    coh2.er.1 = rbinom(n = 1, size = n.coh2.1, p.er.1)
    coh2.er.0 = rbinom(n = 1, size = n.coh2.0, p.er.0)
    coh2.er = cbind(coh2.er.1, coh2.er.0, n.coh2.1 - coh2.er.1, n.coh2.0 - coh2.er.0)
    
    
    ### Final analysis ### 
    # Cohort 2
    coh2.pe_sim = rbinom(n = 4, size = coh2.er, c(p11.1, p11.0, p01.1, p01.0)) 
    coh2.pe = cbind(coh2.pe_sim[1] + coh2.pe_sim[3], coh2.pe_sim[2] + coh2.pe_sim[4])
    
    # Cohort 3: 
    n.coh3.1 = n.1-n.interim.1; n.coh3.0 = n.0-n.interim.0
    coh3.pe = rbinom(n = 2, size = c(n.coh3.1, n.coh3.0), c(p.pe.1, p.pe.0))
    
    # Total 
    total.events = coh1.pe + coh2.pe + coh3.pe
    total[[i]] = c(total.events[1], total.events[2],
                   n.1-total.events[1], n.0-total.events[2])
    
    zt_final = switch(alternative, 
                greater = .TestStatistic.positive(total[[i]], ni.margin = ni.margin),
                less = .TestStatistic.negative(total[[i]], ni.margin = ni.margin))
   
    p.rej_final[i] =1-pnorm(zt_final)
    
    
    
    #########################################
    ###### Calculate Conditional Power ###### 
    #########################################
    
    
    coh1.er.pe.1 = c(coh1.pe_1[1], coh1.er.1-coh1.pe_1[1], coh1.pe_1[3], n.coh1.1-coh1.er.1-coh1.pe_1[3])
    coh1.er.pe.0 = c(coh1.pe_1[2], coh1.er.0-coh1.pe_1[2], coh1.pe_1[4], n.coh1.0-coh1.er.0-coh1.pe_1[4])
    
    
    
    ### Calculate Expected Conditional Power ###
    
    ExpectedConditionalPower[[i]] = Ecp(n.1 = n.1, n.0 = n.0, coh1.er.pe.1 = coh1.er.pe.1, coh1.er.pe.0 = coh1.er.pe.0, 
                                                             coh2.er = coh2.er, prior.1 = prior.1, prior.0 = prior.0, p.pe.1_cp = p.pe.1_cp, 
                                                             p.pe.0_cp = p.pe.0_cp, alternative = alternative, alpha = alpha, method = method,
                                                             assumption = assumption, n.simqk = n.simqk,
                                                             ni.margin = ni.margin)[1]
    
  }
  
  gammas = seq(from = 0, to = 1, by = 0.01)
  fraction.cutoff = .calculate.pfutility(cutoff, unlist(ExpectedConditionalPower))
  fraction.gammas = sapply(gammas, FUN = .calculate.pfutility , unlist(ExpectedConditionalPower))
  
  powerReduction.cutoff = .PowerReduction(cutoff, unlist(ExpectedConditionalPower),
                                          p.rej_final, alpha, n.trials)
  powerReduction.gammas = sapply(gammas, FUN = .PowerReduction , unlist(ExpectedConditionalPower),
                                 p.rej_final, alpha, n.trials)
  
  fit = list(ExpectedConditionalPower = ExpectedConditionalPower, 
             powerReduction.cutoff = powerReduction.cutoff,
             fraction.cutoff = fraction.cutoff, 
             powerReduction.gammas = powerReduction.gammas, 
             fraction.gammas = fraction.gammas, cutoff = cutoff, 
             total = total, p.rej_final = p.rej_final, 
             Call = match.call())
  class(fit) = "sim.Ecp"
  fit
  
}
