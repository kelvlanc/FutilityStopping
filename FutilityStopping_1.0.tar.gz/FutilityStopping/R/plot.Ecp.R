plot.Ecp = function(x, group = "treatment",
                                         Par = par(oma = c(0, 0, 0, 0), mar = c(5.1, 4.1, 4.1, 2.1)),
                                         ...){
  
  Object = x
  data = as.data.frame(cbind(cp = Object$cp_values, k.trt = Object$eta[,1], 
               k.pbo = Object$eta[,2], q.trt = Object$eta[,3], q.pbo = Object$eta[,4]))
  
  ecp = round(Object$ExpectedConditionalPower, digits = 3)
  min = round(min(Object$cp_values), digits = 3)
  max = round(max(Object$cp_values), digits = 3)
  p.pe.1_cp = Object$p.pe.1_cp
  p.pe.0_cp = Object$p.pe.0_cp
  
  switch(group, treatment = qplot(data$k.trt, data$q.trt, data=data, color=data$cp, xlim = c(0,1), ylim = c(0,1),
        xlab="P(PE|ER=1)", ylab="P(PE|ER=0)") +
    scale_colour_gradientn(colours = c("red4", "red2","red", "orangered",  "darkorange", 
                                       "darkgoldenrod1", "yellow", "yellow2", "yellowgreen",
                                       "springgreen3", "springgreen4"), limits = c(0,1),
                           breaks = c(0, 0.3, 0.5, 0.8,  1),
                           values = c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9,  1),
                           labels = c(0, 0.3, 0.5, 0.8,  1), 
                           guide = "colourbar") +
    ggtitle("Treatment Group") + 
    annotate("text", x = 0.11, y = 0.25, 
             label = paste("ECP =  ", ecp), size = 4) + 
    annotate("text", x = 0.11, y = 0.15, 
             label = paste("CP-range =  ", min, "-", max), size = 4) +
    annotate("rect", xmin = p.pe.1_cp, xmax = 1, ymin = 0, ymax = p.pe.1_cp,
             alpha = .2)+
    annotate("rect", xmin = 0, xmax = p.pe.1_cp, ymin = p.pe.1_cp, ymax = 1,
             alpha = .2),
    control = qplot(data$k.pbo, data$q.pbo, data=data, color=data$cp, xlim = c(0,1), ylim = c(0,1),
        xlab="P(Y|X=1)", ylab="P(Y|X=0)") +
    scale_colour_gradientn(colours = c("red4", "red2","red", "orangered",  "darkorange", 
                                       "darkgoldenrod1", "yellow", "yellow2", "yellowgreen",
                                       "springgreen3", "springgreen4"), limits = c(0,1),
                           breaks = c(0, 0.3, 0.5, 0.8,  1),
                           values = c(0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9,  1),
                           labels = c(0, 0.3, 0.5, 0.8,  1), 
                           guide = "colourbar") +
    ggtitle("Control Group") +
    annotate("text", x = 0.11, y = 0.25, 
             label = paste("CP-range =  ", ecp), size = 4) + 
    annotate("text", x = 0.11, y = 0.15, 
             label = paste("ECP =  ", min, "-", max), size = 4) +
    annotate("rect", xmin = p.pe.0_cp, xmax = 1, ymin = 0, ymax = p.pe.0_cp,
             alpha = .2)+
    annotate("rect", xmin = 0, xmax = p.pe.0_cp, ymin = p.pe.0_cp, ymax = 1,
             alpha = .2)
    )
  
}
