plot.sim.Ecp = function(x, xlab, ylab, main,
                                      Par = par(oma = c(0, 0, 0, 0), mar = c(5.1, 4.1, 4.1, 2.1)),
                                      ...){
  
  Object = x
  gammas = seq(from = 0, to = 1, by = 0.01)
  
  
  if(missing(xlab)){xlab = expression(paste("Conditional Power Cutoff"))}
  if(missing(ylab)){ylab = expression(paste("P(Stop for Futility)"))}
  if(missing(main)){main = expression(paste("Simulation Results"))}

  plot(gammas  , Object$fraction.gammas
       ,ylim=c(0,1), type = "b", pch = 16
       , xlab = xlab
       , ylab = ylab
       , main = main, ...)
  grid(,lty=2,col=16)
  segments(x0 = 0, y0 = Object$fraction.cutoff, x1 = Object$cutoff, y1 = Object$fraction.cutoff)
  segments(x0 = Object$cutoff, y0 = 0, x1 = Object$cutoff, y1 = Object$fraction.cutoff)
  text(x = Object$cutoff + 0.05, y = Object$fraction.cutoff+ 0.05, paste(Object$fraction.cutoff))

}




