.calc.CondPower_simulation = function(
  p.er.pe, p.pe.1_cp, p.pe.0_cp,
  coh1.pe, coh2.er,
  n.1, n.0, n.interim.1, n.interim.0, 
  n.coh1.1, n.coh1.0, alternative, 
  alpha, ni.margin
){
  
  if ((alternative==c("greater") | alternative==c("less"))==FALSE) {stop ("The specification of the alternative=c(\"...\") argument of the call is incorrect. Use either alternative=c(\"greater\"), or alternative=c(\"less\").")}     
  
  
  ### (q,k)-Values ###
  k.1 = p.er.pe[1]; k.0 = p.er.pe[2]
  q.1 = p.er.pe[3]; q.0 = p.er.pe[4]
  
  
  # Cohort 2
  coh2.pe_sim = rbinom(n = 4, size = coh2.er, c(k.1, k.0, q.1, q.0))
  coh2.pe = c(coh2.pe_sim[1] + coh2.pe_sim[3], coh2.pe_sim[2] + coh2.pe_sim[4])

  
  # Cohort 3 
  n.coh3.1 = n.1-n.interim.1; n.coh3.0 = n.0-n.interim.0
  
  coh3.pe_sim = rbinom(n = 2, size = c(n.coh3.1, n.coh3.0), c(p.pe.1_cp, p.pe.0_cp))
  
  total.events = coh1.pe + coh2.pe + coh3.pe_sim
  total.table = c(total.events[1], total.events[2], 
                      n.1-total.events[1], n.0-total.events[2])
  

  zt = switch(alternative, 
              greater = .TestStatistic.positive(total.table, ni.margin = ni.margin),
              less = .TestStatistic.negative(total.table, ni.margin = ni.margin))

  p.rej=1-pnorm(zt)
  
  fit = p.rej<alpha
  class(fit) = "calc.CondPower_simulation"
  fit
  
}  

