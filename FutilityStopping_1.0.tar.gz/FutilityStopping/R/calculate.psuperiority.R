.calculate.psuperiority = function(gamma, x){
  
  fit = mean(x>gamma)
  class(fit) = "calculate.psuperiority"
  fit
  
} 