Ecp = function(n.1, n.0, coh1.er.pe.1, coh1.er.pe.0, coh2.er,
                                    prior.1 = c(0, 0, 0, 0), prior.0 = c(0, 0, 0, 0),
                                    p.pe.1_cp = NULL, p.pe.0_cp = NULL, alternative = c("greater"), alpha = 0.025,
                                    method = c("simulation"), assumption = c("design"),
                                    n.simqk = 2500,
                                    ni.margin = 0
                                    ){
  
  if ((alternative==c("greater") | alternative==c("less"))==FALSE) {stop ("The specification of the alternative=c(\"...\") argument of the call is incorrect. Use either alternative=c(\"greater\"), or alternative=c(\"less\").")}     
  if ((method==c("simulation") | method==c("analytical"))==FALSE) {stop ("The specification of the method=c(\"...\") argument of the call is incorrect. Use either method=c(\"simulation\"), or method=c(\"analytical\").")}     
  if ((assumption==c("design") | assumption==c("trend"))==FALSE) {stop ("The specification of the design=c(\"...\") argument of the call is incorrect. Use either assumption=c(\"design\"), or assumption=c(\"trend\").")}     
  if((missing(p.pe.1_cp) | missing(p.pe.0_cp)) && assumption==c("design")) {stop ("The specification of p.pe.1_cp of p.pe.0_cp is missing.")}
  
  
  ### Some values ###
  n.coh1.1 = sum(coh1.er.pe.1); n.coh1.0 = sum(coh1.er.pe.0)
  n.interim.1 = n.coh1.1 + coh2.er[1] + coh2.er[3]
  n.interim.0 = n.coh1.0 + coh2.er[2] + coh2.er[4]
  
  if(assumption=="trend"){
    p.pe.1_cp = (coh1.er.pe.1[1]+coh1.er.pe.1[3])/n.coh1.1
    p.pe.0_cp = (coh1.er.pe.0[1]+coh1.er.pe.0[3])/n.coh1.0
  }
  
  
  ### Prior updaten 
  # Odds Ratio
  # Treatment Group
  n11.1 = 0.5 + prior.1[1] + coh1.er.pe.1[1]     
  n10.1 = 0.5 + prior.1[2] + coh1.er.pe.1[2]
  n01.1 = 0.5 + prior.1[3] + coh1.er.pe.1[3]
  n00.1 = 0.5 + prior.1[4] + coh1.er.pe.1[4]
  
  # Placebo Group 
  n11.0 = 0.5 + prior.0[1] + coh1.er.pe.0[1]
  n10.0 = 0.5 + prior.0[2] + coh1.er.pe.0[2]
  n01.0 = 0.5 + prior.0[3] + coh1.er.pe.0[3]
  n00.0 = 0.5 + prior.0[4] + coh1.er.pe.0[4]
  
  # P(X=1)
  X.posterior.1 = c(n11.1 + n10.1 + coh2.er[1], n01.1 + n00.1 + coh2.er[3])
  X.posterior.0 = c(n11.0 + n10.0 + coh2.er[2], n01.0 + n00.0 + coh2.er[4])
  
  ### Number of PE in Cohort 1
  coh1.pe = c(coh1.er.pe.1[1] + coh1.er.pe.1[3], coh1.er.pe.0[1] + coh1.er.pe.0[3])

  
  ### Calculate Expected Conditional Power
  ExpectedConditionalPower = .calc.ExpCondPower(n.1 = n.1, n.0 = n.0, n.interim.1 = n.interim.1,
                                                n.interim.0 = n.interim.0, n.coh1.1 = n.coh1.1, 
                                                n.coh1.0 = n.coh1.0, p.pe.1_cp = p.pe.1_cp, 
                                                p.pe.0_cp = p.pe.0_cp, 
                                                table.1 = c(n11.1, n10.1, n01.1, n00.1), 
                                                table.0 = c(n11.0, n10.0, n01.0, n00.0),
                                                X.posterior.1 = X.posterior.1,
                                                X.posterior.0 = X.posterior.0,
                                                coh1.pe = coh1.pe, coh2.er = coh2.er, 
                                                alternative = alternative, alpha = alpha, 
                                                method = method, assumption = assumption,
                                                n.simqk = n.simqk, ni.margin = ni.margin)
  

  
  fit = list(ExpectedConditionalPower = ExpectedConditionalPower$ExpectedConditionalPower, 
             eta = ExpectedConditionalPower$eta, cp_values = ExpectedConditionalPower$cp_values,
             n.1 = n.1, n.0 = n.0, coh1.er.pe.1 = coh1.er.pe.1, coh2.er = coh2.er,
             coh1.er.pe.0 = coh1.er.pe.0, p.pe.1_cp = p.pe.1_cp, p.pe.0_cp = p.pe.0_cp,
            Call = match.call())
  class(fit) = "Ecp"
  fit
  
}
