determine.Cutoff = function(n.1, n.0, n.coh1.1, n.coh1.0, n.interim.1, n.interim.0, 
                            prior.1 = c(0, 0, 0, 0), prior.0 = c(0, 0, 0, 0),
                            p.pe.1_cp = NULL, p.pe.0_cp = NULL, 
                            alternative = c("greater"), alpha = 0.025,
                            method = c("analytical"), assumption = c("design"),
                            n.simqk = 2500, n.trials = 10000, ni.margin = 0, p.er.1, 
                            p.er.0, p.pe.1, p.pe.0, log.OR.1, log.OR.0, 
                            max.PowerReduction){
  
  if ((alternative==c("greater") | alternative==c("less"))==FALSE) {stop ("The specification of the alternative=c(\"...\") argument of the call is incorrect. Use either alternative=c(\"greater\"), or alternative=c(\"less\").")}     
  if ((method==c("simulation") | method==c("analytical"))==FALSE) {stop ("The specification of the method=c(\"...\") argument of the call is incorrect. Use either method=c(\"simulation\"), or method=c(\"analytical\").")}     
  if ((assumption==c("design") | assumption==c("trend"))==FALSE) {stop ("The specification of the design=c(\"...\") argument of the call is incorrect. Use either assumption=c(\"design\"), or assumption=c(\"trend\").")}     
  if((missing(p.pe.1_cp) | missing(p.pe.0_cp)) && assumption==c("design")) {stop ("The specification of p.pe.1_cp of p.pe.0_cp is missing.")}
  if(missing(p.er.1) | missing(p.er.0) | missing(p.pe.1) | missing(p.pe.0) | 
      missing(log.OR.1) | missing(log.OR.0)) {
    stop ("The specification of p.er.1, p.er.0, p.pe.1, p.pe.0, log.OR.1 or log.OR.0 is missing.")}
  
  n.scenarios = length(p.er.1)
  if(length(p.er.0)!=n.scenarios | length(p.pe.1)!=n.scenarios | 
     length(p.pe.0)!=n.scenarios | length(log.OR.1)!=n.scenarios |
     length(log.OR.0)!=n.scenarios | length(max.PowerReduction)!=n.scenarios){
    "The length of p.er.1, p.er.0, p.pe.1, p.pe.0, log.OR.1 and log.OR.0 are not equal."
  }
  
  reductions = list(NULL)
  simulation_results = list(NULL)
  cutoffs_index = c()
  
  for(i in 1:n.scenarios){
    
    simulation_results[[i]] = sim.Ecp(n.1, n.0, n.coh1.1, n.coh1.0, n.interim.1, n.interim.0, 
                                     prior.1, prior.0,
                                     p.pe.1_cp, p.pe.0_cp, 
                                     p.er.1[i], p.er.0[i], p.pe.1[i], p.pe.0[i],
                                     log.OR.1[i], log.OR.0[i], alternative, alpha,
                                     method, assumption, cutoff=0.50,
                                     n.simqk, n.trials, ni.margin)
    
    
    reductions[[i]] =   simulation_results[[i]]$powerReduction.gammas
    cutoffs_index[i] = max(which(reductions[[i]]<max.PowerReduction[i]))
    
  }
  
  gammas = seq(from = 0, to = 1, by = 0.01)
  cutoff = gammas[min(cutoffs_index)]
  
  fit = list(cutoff = cutoff, simulation.results = simulation_results, Call = match.call())
  
  class(fit) = "determine.Cutoff"
  fit
  
}


