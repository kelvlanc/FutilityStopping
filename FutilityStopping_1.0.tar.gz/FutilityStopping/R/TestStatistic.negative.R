.TestStatistic.negative = function(vector,  ni.margin){
  n.1 = vector[1]+vector[3]
  n.0 = vector[2]+vector[4]
  prop = c(vector[1]/n.1, vector[2]/n.0)
  p.avg = (prop[1] * n.1 + prop[2] * n.0) / (n.1 + n.0)
  fit = ((prop[2]-prop[1] - ni.margin)/sqrt(p.avg*(1-p.avg)*(1/n.1+1/n.0)))
  class(fit) = "TestStatistic.negative"
  fit
}

