.calculate.qk = function(p.pe, p.er, log.OR){
  
  theta=exp(log.OR)
  aa.k=p.er*(theta-1)
  bb.k=-((p.er*theta+p.pe*(theta-1)+(1-p.er)))
  cc.k=p.pe*theta
  dd.k=(bb.k**2-4*aa.k*cc.k)
  k.simulated=(-bb.k-sqrt(dd.k))/(2*aa.k)
  q.simulated=p.pe/(1-p.er)-(p.er)/(1-p.er)*k.simulated
  
  fit = list(k.sim=k.simulated, q.sim=q.simulated)
  class(fit) = "calculate.qk"
  fit
  
}
